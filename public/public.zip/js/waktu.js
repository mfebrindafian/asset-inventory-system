$(function () {
     //Timepicker
     $('#timepicker').datetimepicker({
          format: 'HH:mm',
     });
     $('#timepicker2').datetimepicker({
          format: 'HH:mm',
     });
     $('#timepicker3').datetimepicker({
          format: 'HH:mm',
     });
     $('#timepicker4').datetimepicker({
          format: 'HH:mm',
     });
});
